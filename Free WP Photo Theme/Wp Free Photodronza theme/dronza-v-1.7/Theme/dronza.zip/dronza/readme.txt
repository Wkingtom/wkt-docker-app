=== Dronza ===
Author: GridValley

== Description ==
Dronza – Drone Aerial Photography WordPress Theme is a perfect solution for creating any kind of Drone, 
photography, woocommerce, blog, creative, gallery, media, video production websites that needs a feature rich
and beautiful presence online with flexible design. This is a perfect theme for leaving a positive impression
to your customers.

When it comes to promoting aerial photography and videography services, a wedding videographer would come across 
the need to share the quality of work in an appealing manner. That’s where this theme pack  can offer 
much-needed support and assistance.

Initial release
v-1.0

