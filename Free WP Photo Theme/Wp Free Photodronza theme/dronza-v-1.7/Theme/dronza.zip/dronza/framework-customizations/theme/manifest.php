<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['id'] = 'dronza';

$manifest['supported_extensions'] = array(
	'backups' => array(),
);
